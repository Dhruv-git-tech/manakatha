
# ManaKatha – Telugu Story Sharing App

ManaKatha is a Telugu-language story-sharing web app powered by AI. Users can write and share stories, and the app provides AI-generated compliments, emojis, and a rating.

## Features

- Submit Telugu stories with optional title and tags.
- Sentiment analysis using AI4Bharat IndicBERT or fallback.
- AI-based appreciation and emoji reactions.
- Star rating based on emotion, clarity, and length.
- Option to share stories publicly.

## Getting Started

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Future Improvements

- Voice story upload with transcription
- User authentication and DB integration
- Story search and category filtering
